document.getElementById('newsletter_submit').onclick = function() {
    alert("You've subscribed :)");
}
document.getElementById('milestone_counter_id1').innerHTML = Math.floor(Math.random() * 100);
document.getElementById('milestone_counter_id2').innerHTML = Math.floor(Math.random() * 100);
document.getElementById('milestone_counter_id3').innerHTML = Math.floor(Math.random() * 100);
document.getElementById('milestone_counter_id4').innerHTML = Math.floor(Math.random() * 100);